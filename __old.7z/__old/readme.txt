
Scripts/Frameworks used:
1) Bootstrap
2) bribable
3) jQuery
4) FontAwesome
